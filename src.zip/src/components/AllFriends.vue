<template>

    <div >
        <hr>
        This is from all friends

    <div v-for="(f, index) in friends" :key="index">
        <span>{{f.name}}</span> <br>
        <span>{{f.online}}</span>



    </div>
        <hr>
    </div>



</template>

<script>
    export default {
        name: "AllFriends",
        data(){
            return{
                friends:[
                    {name:'Tajal Islam', online:true},
                    {name:'Sopnil Islam', online:false},
                    {name:'Tajal Islam', online:true},
                    {name:'Sopnil Islam', online:false}
                ]
            }
        }
    }
</script>

<style scoped>

</style>