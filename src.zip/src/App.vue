<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/Tajal.jpg">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
    <AllFriends ></AllFriends>

    <OnlineFriends ></OnlineFriends>
    <NavBar></NavBar>
  </div>

</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import AllFriends from './components/AllFriends.vue'
import NavBar from './components/NavBar.vue'
import OnlineFriends from './components/OnlineFriends.vue'

export default {
  name: 'app',
  components: {
    HelloWorld,
    AllFriends,
    NavBar,
    OnlineFriends
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
  img{
    height: 300px;
    width: 300px;
  }
</style>
